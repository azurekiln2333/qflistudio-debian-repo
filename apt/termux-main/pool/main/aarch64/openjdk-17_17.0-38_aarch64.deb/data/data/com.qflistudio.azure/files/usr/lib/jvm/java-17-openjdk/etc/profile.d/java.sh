export JAVA_HOME=/data/data/com.qflistudio.azure/files/usr/lib/jvm/java-17-openjdk/
