# -*- tcl -*-
# Tcl package index file, version 1.1
#
if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded sqlite3 3.49.1 \
	    [list load [file join $dir libtcl9sqlite3.49.1.so] Sqlite3]
} else {
    package ifneeded sqlite3 3.49.1 \
	    [list load [file join $dir libsqlite3.49.1.so] Sqlite3]
}
