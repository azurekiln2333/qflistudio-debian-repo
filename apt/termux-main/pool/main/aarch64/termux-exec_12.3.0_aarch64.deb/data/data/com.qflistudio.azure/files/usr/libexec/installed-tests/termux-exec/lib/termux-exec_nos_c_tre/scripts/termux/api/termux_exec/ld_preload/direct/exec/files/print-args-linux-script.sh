#!/data/data/com.qflistudio.azure/files/usr/bin/sh

echo "$@"
